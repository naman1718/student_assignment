﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Student_Management.Models
{
    public class Resource {

    #region Properties
    public int ID { get; set; }
    public string ResourceName { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public int? ExpiryStatus { get; set; }
    public int? StudentID { get; set; }
    #endregion
    public List<Resource> GetResurceData() {
      List<Resource> resourcelist = new List<Resource>();
      DataSet ds = new DB().ExecuteGetQuery("select * from taresource");
      if(ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null) {
        foreach(DataRow rawcode in ds.Tables[0].Rows) {
                    Resource resource = new Resource
                    {
                        ID = rawcode.Field<Int32>("ID"),
                        ResourceName = rawcode.Field<string>("ResourceName"),
                        StartDate = rawcode.Field<DateTime>("StartDate"),
                        EndDate = rawcode.Field<DateTime>("EndDate"),
                        ExpiryStatus = rawcode.Field<int>("ResourceExpiryStatus"),
                        StudentID = rawcode.Field<int?>("StudentId")
                    };
                    resourcelist.Add(resource);
        }
      }
      return resourcelist;
    }
    public List<SelectListItem> GetResurceRemainingData() {
      List<SelectListItem> list = new List<SelectListItem>();
      List<Resource> resourcelist = new List<Resource>();
      DataSet ds = new DB().ExecuteGetQuery("select * from taresource where isnull(studentId,'') = ''");
      if(ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null) {
        foreach(DataRow rawcode in ds.Tables[0].Rows) {
                    Resource resource = new Resource
                    {
                        ID = rawcode.Field<Int32>("ID"),
                        ResourceName = rawcode.Field<string>("ResourceName"),
                        StartDate = rawcode.Field<DateTime>("StartDate"),
                        EndDate = rawcode.Field<DateTime>("EndDate"),
                        ExpiryStatus = rawcode.Field<int>("ResourceExpiryStatus"),
                        StudentID = rawcode.Field<int?>("StudentId")
                    };
                    resourcelist.Add(resource);
        }
      }

      foreach(var r in resourcelist) {
        list.Add(new SelectListItem { Text =r.ResourceName,Value = r.ID.ToString() });
      }
      return list;
    }
    public List<Resource> GetResurceLinkedData(int studentId) {
      List<Resource> resourcelist = new List<Resource>();
      DataSet ds = new DB().ExecuteGetQuery(string.Format("select * from taresource where studentId = {0}",studentId));
      if(ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null) {
        foreach(DataRow rawcode in ds.Tables[0].Rows) {
                    Resource resource = new Resource
                    {
                        ID = rawcode.Field<Int32>("ID"),
                        ResourceName = rawcode.Field<string>("ResourceName"),
                        StartDate = rawcode.Field<DateTime>("StartDate"),
                        EndDate = rawcode.Field<DateTime>("EndDate"),
                        ExpiryStatus = rawcode.Field<int>("ResourceExpiryStatus"),
                        StudentID = rawcode.Field<int?>("StudentId")
                    };
                    resourcelist.Add(resource);
        }
      }
      return resourcelist;
    }

        public Resource GetSingleResourceData(int id)
        {
            Resource resource = new Resource();
            DataSet ds = new DB().ExecuteGetQuery(string.Format("select * from taresource where ID = {0}", id));
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataRow rawcode = ds.Tables[0].Rows[0];
                    resource.ID = rawcode.Field<Int32>("ID");
                    resource.ResourceName = rawcode.Field<string>("ResourceName");
                    resource.StartDate = rawcode.Field<DateTime>("StartDate");
                    resource.EndDate = rawcode.Field<DateTime>("EndDate");
                    resource.ExpiryStatus = rawcode.Field<int>("ResourceExpiryStatus");
                    resource.StudentID = rawcode.Field<int?>("StudentId");
                }
            }
            return resource;
        }

    public void DeleteResourceData(int id) {
      new DB().ExecuteQuery(string.Format("Delete from taresource where ID = {0}",id));
    }
    public void Save() {
      SqlParameter[] param = new SqlParameter[] {
       new SqlParameter("@id",ID),
       new SqlParameter("@resourcename",ResourceName),
       new SqlParameter("@s_date",StartDate),
        new SqlParameter("@e_date",EndDate),
       new SqlParameter("@flag",0)
        };
      new DB().ExecuteStoreProcedure("usp_resource",ref param);
    }

        internal int GetLatestID()
        {
            return (Convert.ToInt32( new DB().ExecuteScalar("select top 1 ID from TaResource order by ID desc") )+ 1);
        }

    }
}
