﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Student_Management.Models
{
    public class Student
    {

        #region Properties
        public long StudentID
        {
            get; set;
        }

        public string StudentName
        {
            get; set;
        }

        public string Department
        {
            get; set;
        }

        public string Gender
        {
            get; set;
        }

        internal long GetLatestID()
        {
            return (Convert.ToInt64( new DB().ExecuteScalar("select top 1 RollNo from tastudent order by RollNo desc") )+1);
        }

        public List<Resource> Resources
        {
            get; set;
        }

        #endregion

        public List<Student> GetStudentData()
        {
            List<Student> studentlist = new List<Student>();
            DataSet ds = new DB().ExecuteGetQuery("select * from tastudent");
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null)
            {
                foreach (DataRow rawcode in ds.Tables[0].Rows)
                {
                    Student student = new Student
                    {
                        StudentID = rawcode.Field<Int64>("RollNo"),
                        StudentName = rawcode.Field<string>("StudentName"),
                        Department = rawcode.Field<string>("Department")
                    };
                    studentlist.Add(student);
                }
            }
            return studentlist;
        }

        public void SaveLinkedResources(HomeModel model)
        {
            foreach (var x in model.SelectedResources)
            {
                new DB().ExecuteQuery(string.Format("update taresource set studentid='{0}' where id= '{1}'", model.studentId, x));
            }
        }

        internal void Delinkresource(int id, int studentid)
        {
            new DB().ExecuteQuery(string.Format("update taresource set studentid='' where id= '{0}' and studentid='{1}'", id, studentid));
        }

        public Student GetSingleStudentData(int id)
        {
            Student student = new Student();
            DataSet ds = new DB().ExecuteGetQuery(string.Format("select * from tastudent where RollNo = {0}", id));
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataRow rawcode = ds.Tables[0].Rows[0];
                    student.StudentID = rawcode.Field<Int64>("RollNo");
                    student.StudentName = rawcode.Field<string>("StudentName");
                    student.Department = rawcode.Field<string>("Department");
                }
            }
            return student;
        }

        public void DeleteStudentData(int id)
        {
            Student student = new Student();
            new DB().ExecuteQuery(string.Format("Delete from tastudent where RollNo = {0}", id));
        }

        public void Save()
        {
            SqlParameter[] param = new SqlParameter[] {
       new SqlParameter("@rollno",StudentID),
       new SqlParameter("@name",StudentName),
       new SqlParameter("@department",Department),
       new SqlParameter("@flag",0)
        };
            new DB().ExecuteStoreProcedure("usp_student", ref param);
        }
    }

    public class HomeModel
    {

        public int studentId { get; set; }
        public IList<string> SelectedResources
        {
            get; set;
        }
        public IList<SelectListItem> AvailableResources
        {
            get; set;
        }

        public HomeModel()
        {
            SelectedResources = new List<string>();
            AvailableResources = new List<SelectListItem>();
        }
    }
}
