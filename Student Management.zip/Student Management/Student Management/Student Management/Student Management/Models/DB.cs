﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Student_Management.Models
{
    public class DB
    {
        string connectionString = @"Server=LAPTOP-B6D38NTD;Database=SManagement;User ID=Naman;Password=Naman;Trusted_Connection=false;Timeout=2000;";

        public DataSet ExecuteGetQuery(string query)
        {
            try
            {
                SqlConnection cn = new SqlConnection(connectionString);
                cn.Open();
                DataSet ds = new DataSet();
                SqlDataAdapter myAdapter = new SqlDataAdapter(query, cn);
                myAdapter.Fill(ds);
                cn.Close();
                return ds;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public void ExecuteQuery(string query)
        {
            try
            {
                SqlConnection cn = new SqlConnection(connectionString);
                cn.Open();
                SqlCommand cm = new SqlCommand(query, cn);
                cm.ExecuteNonQuery();
                cn.Close();
            }
            catch (Exception ex)
            {
            }
        }
        public void ExecuteStoreProcedure(string procedurename, ref SqlParameter[] parameters)
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = procedurename;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 0;
                    foreach (SqlParameter param in parameters)
                    {
                        cmd.Parameters.Add(param);
                    }
                    cmd.ExecuteNonQuery();
                }
                con.Close();
            }
            catch (Exception ex)
            {
            }
        }

        public object ExecuteScalar(string query)
        {
            try
            {
                SqlConnection cn = new SqlConnection(connectionString);
                cn.Open();
                SqlCommand cm = new SqlCommand(query, cn);
                var returnValue = cm.ExecuteScalar();
                if (returnValue != null)
                    return returnValue;
                cn.Close();
            }
            catch (Exception ex)
            {
            }
            return null;
        }

    }


}
