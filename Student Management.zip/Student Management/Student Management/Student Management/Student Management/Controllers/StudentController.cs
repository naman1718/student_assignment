﻿using Microsoft.AspNetCore.Mvc;
using Student_Management.Models;
using System.Collections.Generic;
namespace Student_Management.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult StudentDetails()
        {
            List<Student> datalist = new Student().GetStudentData();
            return View(datalist);
        }

        public IActionResult Create(Student student = null)
        {

            if (student == null || student.StudentID < 1)
            {
                student.StudentID = student.GetLatestID();
                return View(student);
            }
            student.Save();
            return RedirectToAction("StudentDetails");
        }
        [HttpPost]
        public IActionResult SaveResource(HomeModel model)
        {
            if (ModelState.IsValid)
            {
                new Student().SaveLinkedResources(model);
            }
            return RedirectToAction("StudentDetails");
        }
        public IActionResult Delete(int id)
        {
            new Student().DeleteStudentData(id);
            return RedirectToAction("StudentDetails");
        }
        public IActionResult Edit(int id)
        {
            Student studentobj = new Student().GetSingleStudentData(id);
            return View("Create", studentobj);
        }
    }
}
